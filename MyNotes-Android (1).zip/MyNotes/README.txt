My Notes - Android project

1. Install Android Studio (free) on a computer.
2. File > Open, choose this MyNotes folder, wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. When it finishes, click "locate". Send app-debug.apk to your phone and install it
   (allow "install unknown apps" when asked).

The whole app is app/src/main/assets/index.html. The app has no internet permission,
so it works fully offline and cannot send your data anywhere.
Notes and vault files live inside the app. Uninstalling the app deletes them.
